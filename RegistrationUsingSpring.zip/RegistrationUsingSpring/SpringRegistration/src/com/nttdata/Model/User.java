package com.nttdata.Model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

public class User {
	@NotEmpty(message="required")
	private int userId;
    @NotEmpty(message="User name should not be Empty")
	private String username;
    @NotEmpty(message="enter valid password")
    @Size(min=6,max=12,message="password should have 6 to 12 charecters")
	private String password;
    @NotEmpty(message="provide your address")
    private String address;
    @NotEmpty
	@Email
	private String email;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
    
}
