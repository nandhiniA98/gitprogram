package com.nttdata;

public class Category {
	 private int categoryId;
	 private String categoryName;
	 private int forevenId;
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public int getForevenId() {
		return forevenId;
	}
	public void setForevenId(int forevenId) {
		this.forevenId = forevenId;
	}
	 

}
