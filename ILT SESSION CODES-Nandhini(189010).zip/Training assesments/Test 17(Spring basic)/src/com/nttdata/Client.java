package com.nttdata;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class Client {
public static void main(String[] args)
{
	Resource res=new ClassPathResource("SpringConfig.xml");
	BeanFactory factory=new XmlBeanFactory(res);
	Object ob1=factory.getBean("id1");
	Object ob2=factory.getBean("id2");
	Book b=(Book)ob1;
	b.setBookName("wings of fire");
	b.setBookPrice(1000);
	Category c=(Category)ob2;
	c.setName("Autobiograhy");
	c.setBook(b);
	c.show();
	}
}
