package com.nttdata;

public class Category {
	
	private Book book;
	private String name;
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void show(){
		book.show();
		System.out.println("the category  is:  " +name);
		
		
	}
}
