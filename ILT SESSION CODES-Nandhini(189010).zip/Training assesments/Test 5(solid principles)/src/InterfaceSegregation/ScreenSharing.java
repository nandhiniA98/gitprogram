package InterfaceSegregation;

public interface ScreenSharing {
public void shareScreen();
}
