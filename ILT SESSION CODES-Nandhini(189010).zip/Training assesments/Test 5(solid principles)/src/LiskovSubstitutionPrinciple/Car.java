package LiskovSubstitutionPrinciple;

public interface Car {

	void turnOnEngine();
    void accelerate();
}