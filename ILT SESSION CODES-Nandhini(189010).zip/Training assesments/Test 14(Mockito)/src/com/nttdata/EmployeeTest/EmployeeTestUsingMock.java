package com.nttdata.EmployeeTest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.nttdata.Dao.EmployeeDao;
import com.nttdata.Model.Employee;

class EmployeeTestUsingMock {

	EmployeeDao employeeDao=Mockito.mock(EmployeeDao.class);
	
	@Test
	 public void testgetEmployeeId() {
		Employee e=new Employee(20,"sai",645486);
		Mockito.when(employeeDao.createEmployee(20)).thenReturn(e);
	
	}
	@Test
	 public void testListEmployee() {
		
		List<Employee> list=new ArrayList<>();
		list.add(new Employee(12,"arun",45686));
		list.add(new Employee(14,"john",56453));
		list.add(new Employee(16,"rahul",867675));
		list.add(new Employee(11,"priya",96786));
		list.add(new Employee(18,"ram",87323));
		list.add(new Employee(20,"sai",645486));
		Mockito.when(employeeDao.listEmployee()).thenReturn(list);		
	
	}
	
	@Test
	 public void testCreateEmployee() {
		Employee e=new Employee(20,"sai",645486);
		Mockito.when(employeeDao.createEmployee()).thenReturn(e);
	
	}
	@Test
	 public void testDeleteEmployee() {
		

		Employee e=new Employee(20,"sai",645486);
		Mockito.when(employeeDao.deleteEmployee(20)).thenReturn("deleted data"+e);
	
	}
	@Test
	 public void testSearchEmployee() {
		Employee e=new Employee(16,"rahul",867675);
		Mockito.when(employeeDao.searchEmployee("rahul")).thenReturn("searched data"+e);
	
	}
	
}
