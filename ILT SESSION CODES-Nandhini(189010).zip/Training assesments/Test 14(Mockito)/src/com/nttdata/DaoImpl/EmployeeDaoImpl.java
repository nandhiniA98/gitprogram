package com.nttdata.DaoImpl;

import java.util.List;

import com.nttdata.Dao.EmployeeDao;
import com.nttdata.Model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	
	List<Employee> list;
	@Override
	public Employee createEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> listEmployee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String searchEmployee(String employeeName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object createEmployee(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
