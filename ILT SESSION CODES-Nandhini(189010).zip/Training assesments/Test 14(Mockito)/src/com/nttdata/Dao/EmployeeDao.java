package com.nttdata.Dao;

import java.util.List;

import com.nttdata.Model.Employee;

public interface EmployeeDao {
	
	
	Employee createEmployee();
	List<Employee> listEmployee();
	String deleteEmployee(int i);
	String searchEmployee(String string);
	Object createEmployee(int i);
	

}
