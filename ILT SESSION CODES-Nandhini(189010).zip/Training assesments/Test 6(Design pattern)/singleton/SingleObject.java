package singleton;


public class SingleObject {
	//create an object of SingleObject
	   private static SingleObject instance = new SingleObject();

	   //make the constructor private so that this class cannot be
	   //instantiated
	   private SingleObject(){}

	   //Get the only object available
	  

	   public void showMessage(){
	      System.out.println("singleton pattern Implementation");
	   }



	public static SingleObject getInstance() {
		// TODO Auto-generated method stub
		return instance;
	}

}