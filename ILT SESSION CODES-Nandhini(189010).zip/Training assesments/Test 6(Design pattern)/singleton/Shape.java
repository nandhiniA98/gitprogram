package singleton;

public interface Shape {

	
	void Area(int a,int b);
	
}
