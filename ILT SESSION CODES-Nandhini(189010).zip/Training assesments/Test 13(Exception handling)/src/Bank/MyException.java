package Bank;

public class MyException {

	public static void main(String[] args) {
		System.out.println("welcome to exception handing");
		try {
			String s=null;
			System.out.println();
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
			
		}
		System.out.println("After exception");
	}

}
