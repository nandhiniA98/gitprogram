package Bank;

import java.util.Scanner;

import Bank.Account;
import Bank.Bank;
import Bank.InsufficientAmount;
import Bank.User;

public class Client {

	public static void main(String[] args) throws InsufficientAmount {
		 System.out.println("WELCOME TO BANK APPLICATION");
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Press 1. CREATE ACCOUNT   2. TRANSFERFUNDS   3.QUIT");
		 int select =sc.nextInt();
		 if(select==1)
		 {
			 System.out.println("Press 1. CREATE ACCOUNT   2. REPEAT ACCOUNTCREATION ");
			 int select1 =sc.nextInt();
			 
			 if(select1==1)
			 {
				 System.out.println("Enter Username");
				 String UserName=sc.next();			 
				 System.out.println("Enter Account id");
				 int AccountId=sc.nextInt();
				 System.out.println("Enter Amount");
				 int Amount=sc.nextInt(); 
				 System.out.println("Name: "+UserName+ "  AccountId: "+ AccountId+" Amount: "+AccountId); 
			 }
			 else if(select1==2)
			 {
				 System.out.println("Enter Username");
				 String UserName=sc.next();			 
				 System.out.println("Enter Account id");
				 int AccountId=sc.nextInt();
				 System.out.println("Enter Amount");
				 int Amount=sc.nextInt();
				 
				 System.out.println("Name: "+UserName+ "  AccountId: "+ AccountId+" Amount: "+AccountId); 
			 }
			
			 
		 }
		 else if(select==2)
		 {
				System.out.println("1.  TRANSFER AMOUNT  2.QUIT");
				int ip=sc.nextInt();
				if(ip==1)
				{					
									Account acct1=new Account(1,2300);
									User user1=new User("user1", acct1);
									Account acct2=new Account(1,5000);
									User user2=new User("user2", acct2);
									System.out.println(user1);
									System.out.println(user2);
									System.out.println(" 1.FROM user1 to user2  2.user2 to user1   3.Quit");
									int n=sc.nextInt();
									if(n==1) {
									System.out.println("ENTER AMOUNT ");
									double amount=sc.nextDouble();
								    Bank bank=new Bank();
									bank.transfer(user1, user2, amount);
									System.out.println("TRANSFER SUCCESSFULL!!!!!!!!!");
									System.out.println("After transfer");
									System.out.println(user1);
									System.out.println(user2);}
									else if(n==2)
									{

										System.out.println("Enter the amount to be transfered");
										double amount=sc.nextDouble();
									    Bank bank=new Bank();
										bank.transfer(user2, user1, amount);
										System.out.println("TRANSFER SUCCESSFULL!!!!!!!!!");
										System.out.println("A");
										System.out.println(user1);
										System.out.println(user2);
									}
		 else if(select==3)
		 {
			 System.exit(0);
		 }

 
 
	}

}
	}
}