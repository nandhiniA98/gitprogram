package com.nttdat;

public class Employee {
	  private String Employeeid;
	    private String Employeename;
	    private Integer salary;
		public String getEmployeeid() {
			return Employeeid;
		}
		public void setEmployeeid(String employeeid) {
			Employeeid = employeeid;
		}
		public String getEmployeename() {
			return Employeename;
		}
		public void setEmployeename(String employeename) {
			Employeename = employeename;
		}
		public Integer getSalary() {
			return salary;
		}
		public void setSalary(Integer salary) {
			this.salary = salary;
		}
		public Employee(String employeeid, String employeename, Integer salary) {
			super();
			Employeeid = employeeid;
			Employeename = employeename;
			this.salary = salary;
		}
		@Override
		public String toString() {
			return "EmployeeNandhini [Employeeid=" + Employeeid + ", Employeename=" + Employeename + ", salary="
					+ salary + "]";
		}
	    
	    
}
