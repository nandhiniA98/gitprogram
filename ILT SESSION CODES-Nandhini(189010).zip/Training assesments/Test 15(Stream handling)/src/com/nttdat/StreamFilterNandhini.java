package com.nttdat;

import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


 
public class StreamFilterNandhini {
 
    public static void main(String a[]) {
 
        List<Employee> empList = new ArrayList<>();
        empList.add(new Employee("12", "Nandhini", 23350));
        empList.add(new Employee("13", "Dharshini", 92100));
        empList.add(new Employee("14", "Kumar", 530));
        empList.add(new Employee("15", "Karthi", 124200));
 
        // find employees whose salaries are above 10000
        empList.stream().filter(emp->emp.getSalary() > 10000).forEach(System.out::println);
        long emp1= empList.stream().filter(emp->emp.getSalary() > 10000).count();
        System.out.println("Employees have salary more than 10000 ARE:"+emp1);
    }
}