package Vehicles;

public class Vehicle {
	
	
protected int Number;
protected String Name;
protected int price;
protected String color;

public int getNumber() {
	return Number;
}
public void setNumber(int number) {
	Number = number;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}

@Override
public String toString() {
	return "Vehicle [Number=" + Number + ", Name=" + Name + ", price=" + price + ", color=" + color
			+ "]";
}


}
