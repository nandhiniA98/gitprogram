package Employee;

import java.util.ArrayList;

public class EmpDetailsMain {


	
	public static void main(String[] args) {
	
		
		Emp em1=new Emp(101,"Arun","banglore",55000,"5th grade",876645322,"abc@gmail.com");
		Emp em2=new Emp(102,"John","Coimbatote",23400,"6th grade",352322,"dssd@gmail.com");				
	     
		
		ArrayList<Emp> list = new ArrayList<Emp>();

	     // Adding elements to the LinkedList
	     list.add(em1);
	     list.add(em2);
	     
	     
	   for( Emp e: list)
	     System.out.println("Employee Details "+e);
	  }
	}

	
